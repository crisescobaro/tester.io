"use client"

import { useState } from "react"
import { Plus, Package, DollarSign, X, Calendar, User, Hash } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Order {
  id: string
  customerName: string
  product: string
  quantity: number
  price: number
  total: number
  date: string
  status: "pendiente" | "pagado" | "cancelado"
}

export default function InventoryOrders() {
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "001",
      customerName: "María García",
      product: "Laptop Dell",
      quantity: 1,
      price: 800,
      total: 800,
      date: "2024-01-15",
      status: "pendiente",
    },
    {
      id: "002",
      customerName: "Juan Pérez",
      product: "Mouse Inalámbrico",
      quantity: 2,
      price: 25,
      total: 50,
      date: "2024-01-14",
      status: "pagado",
    },
  ])

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newOrder, setNewOrder] = useState({
    customerName: "",
    product: "",
    quantity: 1,
    price: 0,
  })

  const addOrder = () => {
    if (!newOrder.customerName || !newOrder.product || newOrder.price <= 0) {
      return
    }

    const order: Order = {
      id: (orders.length + 1).toString().padStart(3, "0"),
      customerName: newOrder.customerName,
      product: newOrder.product,
      quantity: newOrder.quantity,
      price: newOrder.price,
      total: newOrder.quantity * newOrder.price,
      date: new Date().toISOString().split("T")[0],
      status: "pendiente",
    }

    setOrders([...orders, order])
    setNewOrder({ customerName: "", product: "", quantity: 1, price: 0 })
    setIsDialogOpen(false)
  }

  const updateOrderStatus = (orderId: string, status: "pagado" | "cancelado") => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status } : order)))
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendiente":
        return (
          <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
            Pendiente
          </Badge>
        )
      case "pagado":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Pagado
          </Badge>
        )
      case "cancelado":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            Cancelado
          </Badge>
        )
      default:
        return <Badge variant="outline">Desconocido</Badge>
    }
  }

  const totalPendiente = orders.filter((o) => o.status === "pendiente").reduce((sum, o) => sum + o.total, 0)
  const totalPagado = orders.filter((o) => o.status === "pagado").reduce((sum, o) => sum + o.total, 0)
  const totalCancelado = orders.filter((o) => o.status === "cancelado").reduce((sum, o) => sum + o.total, 0)

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Inventario de Pedidos</h1>
            <p className="text-gray-600 mt-1">Gestiona y controla el estado de todos tus pedidos</p>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Pedido
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Agregar Nuevo Pedido</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="customer">Nombre del Cliente</Label>
                  <Input
                    id="customer"
                    value={newOrder.customerName}
                    onChange={(e) => setNewOrder({ ...newOrder, customerName: e.target.value })}
                    placeholder="Ej: María García"
                  />
                </div>
                <div>
                  <Label htmlFor="product">Producto</Label>
                  <Input
                    id="product"
                    value={newOrder.product}
                    onChange={(e) => setNewOrder({ ...newOrder, product: e.target.value })}
                    placeholder="Ej: Laptop Dell"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quantity">Cantidad</Label>
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      value={newOrder.quantity}
                      onChange={(e) => setNewOrder({ ...newOrder, quantity: Number.parseInt(e.target.value) || 1 })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="price">Precio Unitario ($)</Label>
                    <Input
                      id="price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={newOrder.price}
                      onChange={(e) => setNewOrder({ ...newOrder, price: Number.parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={addOrder} className="bg-blue-600 hover:bg-blue-700">
                    Agregar Pedido
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pedidos</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{orders.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
              <Calendar className="h-4 w-4 text-yellow-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-yellow-600">${totalPendiente.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pagados</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${totalPagado.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cancelados</CardTitle>
              <X className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">${totalCancelado.toFixed(2)}</div>
            </CardContent>
          </Card>
        </div>

        {/* Orders Table */}
        <Card>
          <CardHeader>
            <CardTitle>Lista de Pedidos</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">
                    <div className="flex items-center">
                      <Hash className="w-4 h-4 mr-1" />
                      ID
                    </div>
                  </TableHead>
                  <TableHead>
                    <div className="flex items-center">
                      <User className="w-4 h-4 mr-1" />
                      Cliente
                    </div>
                  </TableHead>
                  <TableHead>Producto</TableHead>
                  <TableHead className="text-center">Cantidad</TableHead>
                  <TableHead className="text-right">Precio Unit.</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Fecha
                    </div>
                  </TableHead>
                  <TableHead>Estado</TableHead>
                  <TableHead className="text-center">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono font-medium">#{order.id}</TableCell>
                    <TableCell className="font-medium">{order.customerName}</TableCell>
                    <TableCell>{order.product}</TableCell>
                    <TableCell className="text-center">{order.quantity}</TableCell>
                    <TableCell className="text-right">${order.price.toFixed(2)}</TableCell>
                    <TableCell className="text-right font-medium">${order.total.toFixed(2)}</TableCell>
                    <TableCell>{order.date}</TableCell>
                    <TableCell>{getStatusBadge(order.status)}</TableCell>
                    <TableCell>
                      <div className="flex justify-center space-x-2">
                        {order.status === "pendiente" && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                              onClick={() => updateOrderStatus(order.id, "pagado")}
                            >
                              <DollarSign className="w-3 h-3 mr-1" />
                              Pagado
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-red-50 text-red-700 border-red-200 hover:bg-red-100"
                              onClick={() => updateOrderStatus(order.id, "cancelado")}
                            >
                              <X className="w-3 h-3 mr-1" />
                              Cancelar
                            </Button>
                          </>
                        )}
                        {order.status !== "pendiente" && (
                          <span className="text-sm text-gray-500 px-3 py-1">
                            {order.status === "pagado" ? "Completado" : "Cancelado"}
                          </span>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {orders.length === 0 && (
              <div className="text-center py-8">
                <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No hay pedidos registrados</p>
                <p className="text-sm text-gray-400">Agrega tu primer pedido para comenzar</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
