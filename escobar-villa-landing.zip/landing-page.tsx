import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Mail, Clock, Star, Shield, Truck, CreditCard } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Component() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-2">
            <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg">
              <span className="text-white font-bold text-lg">EV</span>
            </div>
            <div>
              <h1 className="font-bold text-xl">ESCOBAR Y VILLA</h1>
              <p className="text-xs text-muted-foreground">Vapes & Vaporizadores</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#productos" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Productos
            </Link>
            <Link href="#nosotros" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Nosotros
            </Link>
            <Link href="#contacto" className="text-sm font-medium hover:text-purple-600 transition-colors">
              Contacto
            </Link>
            <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
              Comprar Ahora
            </Button>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container px-4 mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">
                    🚀 Los mejores vapes de Cartago
                  </Badge>
                  <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                    Vapes de{" "}
                    <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                      Calidad Premium
                    </span>{" "}
                    en Colombia
                  </h1>
                  <p className="text-xl text-muted-foreground max-w-lg">
                    Descubre nuestra amplia selección de vapes y vaporizadores de las mejores marcas. Calidad
                    garantizada y envíos a toda Colombia desde Cartago.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    Ver Catálogo
                  </Button>
                  <Button size="lg" variant="outline" className="border-purple-200 hover:bg-purple-50">
                    Contactar WhatsApp
                  </Button>
                </div>
                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>Cartago, Colombia</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span>4.9/5 Calificación</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="relative z-10">
                  <Image
                    src="/placeholder.svg?height=500&width=400"
                    alt="Vapes Premium ESCOBAR Y VILLA"
                    width={400}
                    height={500}
                    className="rounded-2xl shadow-2xl"
                  />
                </div>
                <div className="absolute -top-4 -right-4 w-72 h-72 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full blur-3xl opacity-20"></div>
                <div className="absolute -bottom-4 -left-4 w-72 h-72 bg-gradient-to-r from-pink-400 to-purple-400 rounded-full blur-3xl opacity-20"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Productos Destacados */}
        <section id="productos" className="py-20">
          <div className="container px-4 mx-auto">
            <div className="text-center space-y-4 mb-16">
              <Badge className="bg-purple-100 text-purple-800">Productos Destacados</Badge>
              <h2 className="text-3xl lg:text-4xl font-bold">Nuestros Vapes Más Populares</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Selección premium de vapes y vaporizadores de las mejores marcas internacionales
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  name: "Vape Pod Premium",
                  price: "$89.900",
                  originalPrice: "$120.000",
                  image: "/placeholder.svg?height=300&width=250",
                  features: ["5000 Puffs", "Recargable", "Sabores Variados"],
                },
                {
                  name: "Vaporizador Pro Max",
                  price: "$156.900",
                  originalPrice: "$200.000",
                  image: "/placeholder.svg?height=300&width=250",
                  features: ["8000 Puffs", "Pantalla LED", "Control de Flujo"],
                },
                {
                  name: "Vape Desechable Ultra",
                  price: "$45.900",
                  originalPrice: "$65.000",
                  image: "/placeholder.svg?height=300&width=250",
                  features: ["2500 Puffs", "Compacto", "Sabor Intenso"],
                },
              ].map((product, index) => (
                <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
                  <CardHeader className="p-0">
                    <div className="relative overflow-hidden rounded-t-lg">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={250}
                        height={300}
                        className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <Badge className="absolute top-4 left-4 bg-red-500 hover:bg-red-600">¡Oferta!</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <CardTitle className="text-xl mb-2">{product.name}</CardTitle>
                    <div className="flex items-center space-x-2 mb-4">
                      <span className="text-2xl font-bold text-purple-600">{product.price}</span>
                      <span className="text-lg text-muted-foreground line-through">{product.originalPrice}</span>
                    </div>
                    <ul className="space-y-2 mb-6">
                      {product.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center text-sm text-muted-foreground">
                          <div className="w-2 h-2 bg-purple-600 rounded-full mr-2"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                      Comprar Ahora
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Características */}
        <section className="py-20 bg-muted/50">
          <div className="container px-4 mx-auto">
            <div className="text-center space-y-4 mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold">¿Por Qué Elegir ESCOBAR Y VILLA?</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Somos líderes en vapes en Cartago con años de experiencia y compromiso con la calidad
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: Shield,
                  title: "Productos Auténticos",
                  description: "Solo vendemos productos originales con garantía de calidad",
                },
                {
                  icon: Truck,
                  title: "Envío Rápido",
                  description: "Envíos a toda Colombia desde Cartago en 24-48 horas",
                },
                {
                  icon: CreditCard,
                  title: "Pago Seguro",
                  description: "Múltiples métodos de pago seguros y confiables",
                },
                {
                  icon: Phone,
                  title: "Soporte 24/7",
                  description: "Atención personalizada vía WhatsApp todos los días",
                },
              ].map((feature, index) => (
                <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                  <CardContent className="p-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4">
                      <feature.icon className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl mb-2">{feature.title}</CardTitle>
                    <CardDescription className="text-muted-foreground">{feature.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Sobre Nosotros */}
        <section id="nosotros" className="py-20">
          <div className="container px-4 mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <Badge className="bg-purple-100 text-purple-800">Sobre Nosotros</Badge>
                <h2 className="text-3xl lg:text-4xl font-bold">ESCOBAR Y VILLA - Tu Tienda de Confianza en Cartago</h2>
                <p className="text-lg text-muted-foreground">
                  Somos una empresa familiar establecida en Cartago, Colombia, especializada en la venta de vapes y
                  vaporizadores de alta calidad. Con años de experiencia en el mercado, nos hemos convertido en la
                  referencia local para productos de vapeo.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center mt-1">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold">Experiencia Local</h3>
                      <p className="text-muted-foreground">
                        Conocemos las preferencias y necesidades de nuestros clientes en Cartago
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center mt-1">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold">Calidad Garantizada</h3>
                      <p className="text-muted-foreground">
                        Trabajamos solo con proveedores confiables y marcas reconocidas
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center mt-1">
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    </div>
                    <div>
                      <h3 className="font-semibold">Servicio Personalizado</h3>
                      <p className="text-muted-foreground">
                        Asesoramiento experto para ayudarte a elegir el producto perfecto
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative">
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  alt="Tienda ESCOBAR Y VILLA en Cartago"
                  width={500}
                  height={400}
                  className="rounded-2xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Contacto */}
        <section id="contacto" className="py-20 bg-gradient-to-br from-purple-50 to-pink-50">
          <div className="container px-4 mx-auto">
            <div className="text-center space-y-4 mb-16">
              <Badge className="bg-purple-100 text-purple-800">Contacto</Badge>
              <h2 className="text-3xl lg:text-4xl font-bold">¿Listo para Comprar?</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Contáctanos ahora y obtén los mejores vapes de Cartago con envío a toda Colombia
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <div className="space-y-8">
                <div className="grid sm:grid-cols-2 gap-6">
                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6 text-center">
                      <Phone className="w-8 h-8 text-purple-600 mx-auto mb-4" />
                      <CardTitle className="text-lg mb-2">WhatsApp</CardTitle>
                      <p className="text-muted-foreground">+57 300 123 4567</p>
                      <Button className="mt-4 w-full bg-green-600 hover:bg-green-700">Chatear Ahora</Button>
                    </CardContent>
                  </Card>

                  <Card className="border-0 shadow-lg">
                    <CardContent className="p-6 text-center">
                      <MapPin className="w-8 h-8 text-purple-600 mx-auto mb-4" />
                      <CardTitle className="text-lg mb-2">Ubicación</CardTitle>
                      <p className="text-muted-foreground">Cartago, Valle del Cauca, Colombia</p>
                      <Button variant="outline" className="mt-4 w-full">
                        Ver Mapa
                      </Button>
                    </CardContent>
                  </Card>
                </div>

                <Card className="border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <Clock className="w-6 h-6 text-purple-600" />
                      <CardTitle>Horarios de Atención</CardTitle>
                    </div>
                    <div className="space-y-2 text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Lunes - Viernes:</span>
                        <span>8:00 AM - 8:00 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Sábados:</span>
                        <span>9:00 AM - 6:00 PM</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Domingos:</span>
                        <span>10:00 AM - 4:00 PM</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle>Solicita tu Cotización</CardTitle>
                  <CardDescription>Déjanos tus datos y te contactaremos con la mejor oferta</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Nombre</label>
                      <Input placeholder="Tu nombre completo" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Teléfono</label>
                      <Input placeholder="Tu número de WhatsApp" />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Email</label>
                    <Input type="email" placeholder="tu@email.com" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Ciudad</label>
                    <Input placeholder="¿Desde dónde nos escribes?" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Mensaje</label>
                    <textarea
                      className="w-full p-3 border rounded-md resize-none h-24"
                      placeholder="¿Qué tipo de vape te interesa?"
                    ></textarea>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    Enviar Solicitud
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container px-4 mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg">
                  <span className="text-white font-bold text-lg">EV</span>
                </div>
                <div>
                  <h3 className="font-bold text-lg">ESCOBAR Y VILLA</h3>
                  <p className="text-sm text-gray-400">Vapes & Vaporizadores</p>
                </div>
              </div>
              <p className="text-gray-400">Tu tienda de confianza para vapes premium en Cartago, Colombia.</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Productos</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Vapes Desechables
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Vaporizadores
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Pods Recargables
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Accesorios
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Sobre Nosotros
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Términos y Condiciones
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Política de Privacidad
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Garantías
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Contacto</h4>
              <ul className="space-y-2 text-gray-400">
                <li className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span>Cartago, Colombia</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>+57 300 123 4567</span>
                </li>
                <li className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>info@escobarvilla.com</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} ESCOBAR Y VILLA. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
